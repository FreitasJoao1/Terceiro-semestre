package br.com.api.produtos.servico;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.api.produtos.modelo.RespostaModelo;
import br.com.api.produtos.modelo.UserModelo;
import br.com.api.produtos.repositorio.UserRepositorio;

@Service 

public class LoginServico {
    private final RespostaModelo respostaModelo;
    private final UserRepositorio userRepo;
 
    public LoginServico(UserRepositorio userRepo, RespostaModelo respostaModelo) {
        this.userRepo=userRepo;
        this.respostaModelo = respostaModelo;
    }

    public ResponseEntity<RespostaModelo> login(UserModelo usuarioReq){
        RespostaModelo resposta = new RespostaModelo();

        String usuario=usuarioReq.getUsuario();
        String senha=usuarioReq.getSenha(); // ta correto aqui

        if (usuario==null || usuario.isBlank() || senha==null || senha.isBlank()) {
            resposta.setMensagem("\"Informa o usuario e senha: \"");
            return ResponseEntity.badRequest().body(resposta);
        }

        UserModelo user = userRepo.findById(usuario);
        if (user==null) {
           respostaModelo.setMensagem("usuário não encontrado");
           return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);

    }
    if (!senha.equals(user.getSenha())) {
        resposta.setMensagem("Senha incorreta. ");
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(resposta);
    }
    resposta.setMensagem("Login realizado com sucesso!");
    return ResponseEntity.ok(resposta);
}
}